# ESP32 Experiments

A lightweight bench tool for ESP32 boards, running inside Brewser on Switch hardware.
Talks to a board over **WebSerial** (USB CDC-ACM) with three views.

## Plot — live serial plotter
Send numbers from the board and they graph in real time. Accepted line formats
(one reading per `println`):

```
analogRead: 512                 // named single series
512                             // one bare series (S0)
512, 480, 300                   // three series (S0, S1, S2)
temp:23.5 hum:60 lux:900        // named series, space or comma separated
```

- Bare numbers are keyed by column position (`S0`, `S1`, …); `name:value` /
  `name=value` tokens are keyed by name. Up to 12 series, colour-coded, with a
  live-value legend.
- Lines starting with `#` (or `//`) are treated as comments and ignored by the
  plotter, so firmware can print status/help text without creating fake series.
- **auto-scale Y** fits the visible window; uncheck it to type a fixed Y range.
- **window** sets how many recent samples are shown (200–2000).
- **Pause** freezes the graph (serial keeps flowing); **Clear** drops all series.

Example Arduino loop:

```cpp
void loop() {
  Serial.print(analogRead(1)); Serial.print(',');
  Serial.print(analogRead(2)); Serial.print(",temp:");
  Serial.println(readTempC());
  delay(20);
}
```

## Terminal — raw serial monitor
Text or **hex** view, capped + batched so it stays smooth at high baud. Send box
with selectable line ending (`\n`, `\r\n`, `\r`, none).

## Discover — is my board even enumerating?
- **Scan USB (picker)** lists *every* USB device on the port and dumps its
  descriptor (VID:PID, class, interfaces, endpoints). It flags whether a CDC-ACM
  interface is present — i.e. whether WebSerial can drive it.
- **Scan BLE** finds a device advertising a service UUID (Nordic UART pre-filled).

> A **native-USB ESP32 (S3/C3/C6)** must be built with **USB CDC On Boot: Enabled**
> and plugged into its **native USB** port to appear here as CDC-ACM. Classic
> boards with a CH340/CP210x/FTDI bridge will show up in *Scan USB* but are not
> yet drivable by WebSerial.

## Test firmware
A ready-to-flash companion sketch lives at
[`assets/docs/esp32_experiments_demo.ino`](assets/docs/esp32_experiments_demo.ino).
It streams `sine` / `cos` / `tri` demo channels (plus an optional real ADC pin)
and accepts commands over the Terminal tab (`?`, `id`, `stop`, `rate 20`, `csv`,
`adc <pin>`, `led 1`, `echo …`). Flash it with **USB CDC On Boot: Enabled** and
plug the Switch into the board's native USB port.

## Notes
- Permissions: `usb` (umbrella → also grants serial/hid/midi) + `serial` +
  `bluetooth`. Exit with **+**.
- Kept intentionally cheap: the plot only redraws when data arrives (no idle
  loop), logs are capped, and the chrome avoids shadows/filters/gradients.
