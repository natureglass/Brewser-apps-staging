# FSR Lab

Render small, upscale smart. A live comparison lab for AMD FidelityFX Super
Resolution 1.0 — and a simplified FSR 2-style temporal upscaler — running as
WebGL2 fragment shaders: the same reduced-internal-resolution trick commercial
Switch titles use, measurable on the same GPU through Brewser.

Single self-contained `index.html`, no dependencies, fully offline.

## Pipeline

```
scene ──► low-res FBO (RGBA8, linear)          quality preset × output size
              │        (sub-pixel Halton jitter in temporal mode)
              ├─ left of wipe ──────────────► bilinear stretch (composite pass)
              ├─ EASU ──► full-res FBO ─────────────► RCAS ─► right of wipe
              └─ temporal accumulate ◄─► history ping-pong ─► RCAS ─► right of wipe
```

- **Pass 1** renders the test scene into an off-screen buffer at the selected
  internal resolution (FSR 1.0's official presets: 77 / 67 / 59 / 50%).
- **Pass 2** is EASU into a full-resolution buffer. When the split compare is
  on, this pass is scissored to the visible side of the divider (plus an 8 px
  margin for RCAS's neighbour taps), so the comparison doesn't pay for pixels
  it never shows.
- **Pass 2 (temporal mode)** instead accumulates the jittered low-res frame
  into a full-resolution history buffer (ping-pong pair). This pass is never
  scissored — the history must stay whole across the entire frame so dragging
  the wipe can't expose stale pixels. It's deliberately the heavier mode: a
  full-res read + write per frame, which makes it the more interesting
  Tegra X1 benchmark.
- **Pass 3** composites to the screen: bilinear left of the wipe, the selected
  mode right of it, with RCAS applied inline when active (modes FSR 1.0 + RCAS
  and temporal). In temporal mode the bilinear side is jitter-compensated in
  the composite, so the reference side doesn't wobble. "Native render"
  redraws the scene at full resolution into the same buffer as a ground-truth
  reference (and honest full-cost timing).

## Port notes (GLSL ES 3.00 / WebGL2)

- `textureGather` is ES 3.1 and unavailable in WebGL2, so EASU's 12-texel
  footprint uses the reference's non-gather layout, fetched with edge-clamped
  `texelFetch`.
- The reference's approximate `rcp`/`rsqrt` bit tricks are replaced with exact
  division and `inversesqrt`, with small epsilons where the approximations
  implicitly avoided division by zero. Negligible cost, and it sidesteps any
  driver quirks around `floatBitsToUint` reinterpretation.
- Everything runs in `highp`. EASU's edge-direction math visibly degrades in
  reduced precision.
- All loops and indexing are static — nothing here should stress the Nouveau
  shader compiler.
- The frame-time readout is CPU-side rAF deltas (smoothed EMA + worst frame in
  a 60-frame window). `EXT_disjoint_timer_query` isn't assumed, so per-pass GPU
  timings aren't shown; compare modes at the same scene state (freeze frame)
  for fair numbers.
- HUD text updates at 4 Hz so DOM churn doesn't pollute the measurement.

## Controls

| Action | Gamepad | Keyboard / pointer |
| --- | --- | --- |
| Output mode | D-pad left / right | ← → |
| Internal resolution | D-pad up / down | ↑ ↓ |
| Toggle split compare | A | space |
| Pixel zoom 1× / 2× / 4× | B | Z |
| Move the wipe | left stick, L / R | drag anywhere |
| Freeze frame | Y | F |
| Hide interface | X | H |
| RCAS sharpness | ZL / ZR | [ ] (or the slider) |
| Exit | Plus | — |

Lower sharpness values sharpen more (it's FSR's attenuation parameter);
0.2 is the default, 2.0 is nearly off. Sharpness applies to both
FSR 1.0 + RCAS and temporal mode.

## Temporal mode (FSR 2-style)

FSR 1.0 is spatial — it can only sharpen information that survived the
downsample. The temporal mode does what FSR 2 and DLSS actually do: it
collects information across frames.

- **Jitter.** Each frame the scene renders with a sub-pixel offset from an
  8-point Halton(2,3) sequence (±0.5 low-res pixels). Over a cycle, the
  sample grid covers positions between the low-res pixel centres — that's
  where the extra resolution comes from.
- **Confidence-weighted accumulation.** The history buffer stores a running
  per-pixel weight in its alpha channel (capped at 16). Each frame's sample
  is folded in weighted by its confidence `w = exp(-6 d²)`, where `d` is the
  distance from this output pixel to the nearest jittered source sample. A
  fixed-rate EMA does *not* work here — it converges to a blend of all jitter
  phases (i.e. blur); the weighted form converges to the sharp ones.
- **Exact reprojection.** The grid scroll is inverted analytically per pixel
  (`zPrev = zNow + 1.2 dt`), valid at any speed — a luxury of a procedural
  scene; real engines rasterise a motion-vector buffer. Sky geometry is
  static; the sun-stripe crawl and star twinkle are handled by clamping.
- **Rejection.** History weight decays with screen-space speed (quadratic),
  with flow divergence (the floor stretches as it approaches, which blurs
  reprojected history), and with 3×3 neighbourhood-clamp violations
  (ghosting). Fast-scrolling regions thereby fall back toward single-frame
  quality instead of smearing.
- **Stochastic rounding.** A ±0.5 LSB per-frame dither keeps the RGBA8
  history from stalling at low blend rates and debands the sky gradients.

When the frame is frozen, `dt = 0`: the jitter keeps cycling, reprojection is
the identity, the clamp relaxes (the scene is fully static), and the history
converges to an effectively supersampled image in about one jitter cycle —
this is the showcase. Freeze, then wipe.

Verified against a CPU reference of these exact shaders at the 50% preset
(MSE vs the native render, 60 fps motion):

| condition | temporal | bilinear | FSR 1.0 + RCAS |
| --- | --- | --- | --- |
| frozen, converged | **0.0011** | 0.0015 | 0.0013 |
| in motion, whole frame | **0.0015** | 0.0017 | 0.0016 |
| in motion, sky only | **0.0014** | 0.0022 | 0.0022 |
| in motion, floor only | 0.0016 | **0.0014** | 0.0011 |

The floor row is the honest caveat: near the bottom of the screen the grid
moves up to ~77 px per frame — far beyond what games feed a TAA — and there
the rejection logic correctly gives up on history, landing slightly behind
plain bilinear. Everywhere else, and especially on anything static or slow,
temporal wins outright. This is a simplified single-pass design in the spirit
of FSR 2 (no reactive masks, no lock system, no Lanczos history resampling);
it is not AMD's FSR 2 implementation and isn't labelled as such.

## Why the scene looks like that

The synthwave scene is the test chart: thin grid lines, a fine 5× subgrid,
1px lit city windows, rim-lit ridge silhouettes and striped sun edges are
exactly the content where spatial upscalers earn their keep — or fall apart.

Critically, every detail width is defined in **native output pixels** (via a
`uResRatio = renderH / outputH` uniform), not in internal-resolution pixels.
A naive `fwidth`-based scene redraws its lines proportionally thicker at lower
internal resolutions — the low-res frame then contains a *different, fatter*
scene rendered faithfully, every upscaler reproduces it equally well, and FSR
looks identical to bilinear (v1.0.0 had exactly this bug). Calibrated to
native pixels, a reduced internal resolution genuinely under-samples the same
world content, like real game geometry — which is what makes the comparison
honest: bilinear smears it, EASU visibly reconstructs edges, native remains
ground truth. Verified against a CPU reference implementation of these exact
shaders: at the 50% preset, MSE vs the native render drops ~28% going from
bilinear to EASU+RCAS, concentrated on edge pixels.

The pixel zoom (1× / 2× / 4×) magnifies around the screen centre. Both sides
of the wipe are magnified nearest-neighbour from virtual full-res pixel
centres, so the comparison stays per-pixel fair while zoomed. The scissor
optimisation is disabled while zoomed (the divider no longer maps 1:1 to the
full-res buffer).

## License

MIT. EASU and RCAS are ported from AMD FidelityFX Super Resolution 1.0,
Copyright (c) Advanced Micro Devices, Inc., released under the MIT license
(github.com/GPUOpen-Effects/FidelityFX-FSR). Scene, harness and UI by
@natureglass.
