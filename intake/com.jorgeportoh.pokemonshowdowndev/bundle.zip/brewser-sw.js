/* Brewser PWA — injected app service worker (runs on the app's OWN origin, e.g.
 * play.brewser.io/apps/<pkg>/). Placed at the app root so its default scope is the app.
 *
 * The plugin substitutes the CACHE name, the precache list and the start URL at publish.
 * Unlike the WordPress wrapper SW, the app bundle is STATIC and immutable per version, so
 * this is offline-first: precache the whole app on install, then serve cache-first. On the
 * Switch runtime there is no serviceWorker API, so this file is simply never registered.
 */
'use strict';

var CACHE    = 'brewser-app-com-jorgeportoh-pokemonshowdowndev-6a81088cda83';
var PRECACHE = [".\/","pwa\/app.webmanifest","pwa\/brewser-pwa.js","pwa\/icon-192.png","pwa\/icon-512.png","pwa\/icon-maskable.png","pwa\/apple-touch-icon.png","app.js","categories\/physical.png","categories\/special.png","categories\/status.png","favicon.ico","index.html","items\/abilityshield.png","items\/abomasite.png","items\/absolite.png","items\/absolitez.png","items\/absorbbulb.png","items\/adamantcrystal.png","items\/adamantorb.png","items\/adrenalineorb.png","items\/aerodactylite.png","items\/aggronite.png","items\/aguavberry.png","items\/airballoon.png","items\/alakazite.png","items\/altarianite.png","items\/ampharosite.png","items\/apicotberry.png","items\/aspearberry.png","items\/assaultvest.png","items\/audinite.png","items\/auspiciousarmor.png","items\/babiriberry.png","items\/banettite.png","items\/barbaracite.png","items\/baxcalibrite.png","items\/beastball.png","items\/beedrillite.png","items\/berrysweet.png","items\/bignugget.png","items\/bigroot.png","items\/bindingband.png","items\/blackbelt.png","items\/blackglasses.png","items\/blacksludge.png","items\/blastoisinite.png","items\/blazikenite.png","items\/blunderpolicy.png","items\/boosterenergy.png","items\/bottlecap.png","items\/brightpowder.png","items\/cameruptite.png","items\/cellbattery.png","items\/chandelurite.png","items\/charcoal.png","items\/charizarditex.png","items\/charizarditey.png","items\/chartiberry.png","items\/cheriberry.png","items\/chesnaughtite.png","items\/chestoberry.png","items\/chilanberry.png","items\/chimechite.png","items\/chippedpot.png","items\/choiceband.png","items\/choicescarf.png","items\/choicespecs.png","items\/chopleberry.png","items\/clearamulet.png","items\/clefablite.png","items\/cloversweet.png","items\/cobaberry.png","items\/colburberry.png","items\/cornerstonemask.png","items\/covertcloak.png","items\/crabominite.png","items\/crackedpot.png","items\/custapberry.png","items\/damprock.png","items\/dawnstone.png","items\/delphoxite.png","items\/destinyknot.png","items\/diveball.png","items\/dracoplate.png","items\/dragalgite.png","items\/dragonfang.png","items\/dragoninite.png","items\/dragonscale.png","items\/drampanite.png","items\/dreadplate.png","items\/dreamball.png","items\/dubiousdisc.png","items\/duskball.png","items\/duskstone.png","items\/earthplate.png","items\/eelektrossite.png","items\/ejectbutton.png","items\/ejectpack.png","items\/electirizer.png","items\/electricseed.png","items\/emboarite.png","items\/enigmaberry.png","items\/eviolite.png","items\/excadrite.png","items\/expertbelt.png","items\/fairyfeather.png","items\/falinksite.png","items\/fastball.png","items\/feraligite.png","items\/figyberry.png","items\/firestone.png","items\/fistplate.png","items\/flameorb.png","items\/flameplate.png","items\/floatstone.png","items\/floettite.png","items\/flowersweet.png","items\/focusband.png","items\/focussash.png","items\/friendball.png","items\/froslassite.png","items\/galaricacuff.png","items\/galaricawreath.png","items\/galladite.png","items\/ganlonberry.png","items\/garchompite.png","items\/garchompitez.png","items\/gardevoirite.png","items\/gengarite.png","items\/glalitite.png","items\/glimmoranite.png","items\/goldbottlecap.png","items\/golisopite.png","items\/golurkite.png","items\/grassyseed.png","items\/greatball.png","items\/greninjite.png","items\/grepaberry.png","items\/gripclaw.png","items\/griseouscore.png","items\/griseousorb.png","items\/gyaradosite.png","items\/habanberry.png","items\/hardstone.png","items\/hawluchanite.png","items\/healball.png","items\/hearthflamemask.png","items\/heatrock.png","items\/heavyball.png","items\/heavydutyboots.png","items\/heracronite.png","items\/hondewberry.png","items\/houndoominite.png","items\/iapapaberry.png","items\/icestone.png","items\/icicleplate.png","items\/icyrock.png","items\/insectplate.png","items\/ironball.png","items\/ironplate.png","items\/jabocaberry.png","items\/kangaskhanite.png","items\/kasibberry.png","items\/kebiaberry.png","items\/keeberry.png","items\/kelpsyberry.png","items\/kingsrock.png","items\/laggingtail.png","items\/lansatberry.png","items\/leafstone.png","items\/leek.png","items\/leftovers.png","items\/leppaberry.png","items\/levelball.png","items\/liechiberry.png","items\/lifeorb.png","items\/lightball.png","items\/lightclay.png","items\/loadeddice.png","items\/lopunnite.png","items\/loveball.png","items\/lovesweet.png","items\/lucarionite.png","items\/lucarionitez.png","items\/lumberry.png","items\/luminousmoss.png","items\/lureball.png","items\/lustrousglobe.png","items\/lustrousorb.png","items\/luxuryball.png","items\/magmarizer.png","items\/magnet.png","items\/magoberry.png","items\/malamarite.png","items\/maliciousarmor.png","items\/manectite.png","items\/marangaberry.png","items\/masterball.png","items\/masterpieceteacup.png","items\/mawilite.png","items\/meadowplate.png","items\/medichamite.png","items\/meganiumite.png","items\/mentalherb.png","items\/meowsticite.png","items\/metagrossite.png","items\/metalalloy.png","items\/metalcoat.png","items\/metronome.png","items\/micleberry.png","items\/mindplate.png","items\/miracleseed.png","items\/mirrorherb.png","items\/mistyseed.png","items\/moonball.png","items\/moonstone.png","items\/muscleband.png","items\/mysticwater.png","items\/nestball.png","items\/netball.png","items\/nevermeltice.png","items\/normalgem.png","items\/occaberry.png","items\/oranberry.png","items\/ovalstone.png","items\/passhoberry.png","items\/payapaberry.png","items\/pechaberry.png","items\/persimberry.png","items\/petayaberry.png","items\/pidgeotite.png","items\/pinsirite.png","items\/pixieplate.png","items\/poisonbarb.png","items\/pokeball.png","items\/pomegberry.png","items\/poweranklet.png","items\/powerband.png","items\/powerbelt.png","items\/powerbracer.png","items\/powerherb.png","items\/powerlens.png","items\/powerweight.png","items\/premierball.png","items\/prettyfeather.png","items\/prismscale.png","items\/protectivepads.png","items\/protector.png","items\/psychicseed.png","items\/punchingglove.png","items\/pyroarite.png","items\/qualotberry.png","items\/quickball.png","items\/quickclaw.png","items\/raichunitex.png","items\/raichunitey.png","items\/rarebone.png","items\/rawstberry.png","items\/razorclaw.png","items\/razorfang.png","items\/reapercloth.png","items\/redcard.png","items\/repeatball.png","items\/ribbonsweet.png","items\/rindoberry.png","items\/ringtarget.png","items\/rockyhelmet.png","items\/roomservice.png","items\/roseliberry.png","items\/rowapberry.png","items\/rustedshield.png","items\/rustedsword.png","items\/sablenite.png","items\/safariball.png","items\/safetygoggles.png","items\/salacberry.png","items\/salamencite.png","items\/sceptilite.png","items\/scizorite.png","items\/scolipite.png","items\/scopelens.png","items\/scovillainite.png","items\/scraftinite.png","items\/sharpbeak.png","items\/sharpedonite.png","items\/shedshell.png","items\/shellbell.png","items\/shinystone.png","items\/shucaberry.png","items\/silkscarf.png","items\/silverpowder.png","items\/sitrusberry.png","items\/skarmorite.png","items\/skyplate.png","items\/slowbronite.png","items\/smoothrock.png","items\/snowball.png","items\/softsand.png","items\/souldew.png","items\/spelltag.png","items\/splashplate.png","items\/spookyplate.png","items\/sportball.png","items\/staraptite.png","items\/starfberry.png","items\/starminite.png","items\/starsweet.png","items\/steelixite.png","items\/stickybarb.png","items\/stoneplate.png","items\/strawberrysweet.png","items\/sunstone.png","items\/swampertite.png","items\/sweetapple.png","items\/syrupyapple.png","items\/tamatoberry.png","items\/tangaberry.png","items\/tartapple.png","items\/terrainextender.png","items\/throatspray.png","items\/thunderstone.png","items\/timerball.png","items\/toxicorb.png","items\/toxicplate.png","items\/twistedspoon.png","items\/tyranitarite.png","items\/ultraball.png","items\/unremarkableteacup.png","items\/upgrade.png","items\/utilityumbrella.png","items\/venusaurite.png","items\/victreebelite.png","items\/wacanberry.png","items\/waterstone.png","items\/weaknesspolicy.png","items\/wellspringmask.png","items\/whiteherb.png","items\/widelens.png","items\/wikiberry.png","items\/wiseglasses.png","items\/yacheberry.png","items\/zapplate.png","items\/zoomlens.png","styles.css"];   // JSON array of app-relative URLs
var START    = 'index.html';    // navigation fallback (the app entry)

self.addEventListener('install', function (event) {
	event.waitUntil((async function () {
		var cache = await caches.open(CACHE);
		// Resilient precache: a single missing file must not abort the whole install.
		await Promise.all(PRECACHE.map(function (u) {
			return cache.add(new Request(u, { cache: 'reload' })).catch(function () {});
		}));
		await self.skipWaiting();
	})());
});

self.addEventListener('activate', function (event) {
	event.waitUntil((async function () {
		try {
			var keys = await caches.keys();
			await Promise.all(keys.map(function (k) {
				// Drop this app's stale-version caches; leave everything else alone.
				return (k.indexOf('brewser-app-') === 0 && k !== CACHE) ? caches.delete(k) : Promise.resolve();
			}));
		} catch (e) {}
		await self.clients.claim();
	})());
});

self.addEventListener('fetch', function (event) {
	var req = event.request;
	if (req.method !== 'GET') { return; }

	var url;
	try { url = new URL(req.url); } catch (e) { return; }

	// Cross-origin (fonts, CDNs, APIs the app calls): pass through untouched.
	if (url.origin !== self.location.origin) { return; }

	// Navigations: network-first, fall back to the precached entry when offline.
	if (req.mode === 'navigate') {
		event.respondWith((async function () {
			try {
				return await fetch(req);
			} catch (e) {
				var cache = await caches.open(CACHE);
				return (await cache.match(req)) ||
					(await cache.match(START)) ||
					(await cache.match('./')) ||
					Response.error();
			}
		})());
		return;
	}

	// Same-origin sub-resources: cache-first (the bundle is immutable per version), with a
	// network fill for anything not precached.
	event.respondWith((async function () {
		var cache = await caches.open(CACHE);
		var hit = await cache.match(req);
		if (hit) { return hit; }
		try {
			var res = await fetch(req);
			if (res && res.ok && res.type === 'basic') {
				try { cache.put(req, res.clone()); } catch (e) {}
			}
			return res;
		} catch (e) {
			return (await cache.match(req)) || Response.error();
		}
	})());
});
