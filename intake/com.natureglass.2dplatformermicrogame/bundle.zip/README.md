# 2D Platformer Microgame

_v1.0.0_

**2D Platformer Microgame** is Unity's official learning template — a complete little side-scroller — compiled to WebGL and running natively on the Switch GPU, entirely offline.

**How it works.** This is a real Unity engine build (Unity 2021.3 LTS, Universal Render Pipeline) exported to WebAssembly. The whole game — physics, tilemap, animation, the Cinemachine follow-camera and TextMeshPro UI — runs inside the Brewser runtime through its *WebGL bridge*, which forwards the engine's draw calls to the console's graphics chip. The compressed build was unpacked so it loads from local storage with no web server.

**How you play:**

- **Move** — left stick or D-pad to run left and right.
- **Jump** — the jump button to hop between platforms.
- **Collect & avoid** — grab pickups and dodge hazards through the level.

A full Unity game engine, rendered live on Switch. Built from Unity's free 2D Platformer Microgame template.

---

## Packaging notes

Exported from Unity **2021.3.45f2** (URP `com.unity.render-pipelines.universal@12.1.15`), template `com.unity.template.platformer@4.0.1`.

The Unity WebGL build ships gzip-compressed (`.data.gz`, `.wasm.gz`, `.framework.js.gz`) and relies on the web server sending `Content-Encoding: gzip`. Brewser's local scheme fetch serves raw bytes and does not gunzip, so the three files were **decompressed and the `.gz` suffix dropped**, and `index.html`'s config was repointed at them:

| Shipped file                     | Source (`WebGL Builds/Build/`)     |
| -------------------------------- | ---------------------------------- |
| `Build/platformer.data`          | `WebGL Builds.data.gz` (gunzipped) |
| `Build/platformer.wasm`          | `WebGL Builds.wasm.gz` (gunzipped) |
| `Build/platformer.framework.js`  | `WebGL Builds.framework.js.gz` (gunzipped) |
| `Build/platformer.loader.js`     | `WebGL Builds.loader.js` (copied)  |

`index.html` was also adapted for Switch: the canvas fills the 1280×720 display (the stock template pins a fixed 960×600 desktop window), Unity's mobile-device block was removed (nx.js's user-agent can trip the `Android` check), and `devicePixelRatio` is pinned to 1.

Unity-on-Brewser rendering is confirmed for WebGL1 builds; WebGL2 with GPU instancing has a known unresolved compositing gap on Tegra/Mesa.

- **Placeholder banner:** `assets/appbanner.png` is Unity's logo as a stand-in — replace with a real 16:9 banner before publishing.
- **License:** the microgame template is distributed under the [Unity Companion License](https://unity.com/legal/licenses/unity-companion-license), not MIT.

---

- **Developer:** Alex Daskalakis
- **Brewser profile:** [natureglass](https://brewser.tech/profile?publisher=natureglass)
- **Built from:** Unity 2D Platformer Microgame (Unity Technologies)
- **Website:** [https://github.com/natureglass](https://github.com/natureglass)
